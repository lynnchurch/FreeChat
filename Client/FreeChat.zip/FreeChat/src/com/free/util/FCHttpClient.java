package com.free.util;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.free.exception.FCException;
import com.free.exception.FCNetworkUnconnectedException;

public class FCHttpClient {
	static private FCHttpClient fCHttpClient = null;

	private FCHttpClient() {

	}

	public void doPost(String url, Map<?, ?> params)
			throws FCException {

		// 构造HttpClient的实例
		HttpClient httpClient = new DefaultHttpClient();
		// 创建Post的实例
		HttpPost httpPost = new HttpPost(url);
		// 添加http头信息
//		httpPost.addHeader("Authorization", "your token"); // 认证token
//		httpPost.addHeader("Content-Type", "application/json");
//		httpPost.addHeader("User-Agent", "imgfornote");

		try {
			// 设置HttpPost数据
			if (params != null) {
				// 填入各个表单域的值
				JSONObject data = null;

				Set<?> sets = params.keySet();
				Object[] arr = sets.toArray();
				int mxsets = sets.size();
				if (mxsets > 0) {
					data = new JSONObject();
					for (int i = 0; i < mxsets; i++) {
						String key = (String) arr[i];
						String val = (String) params.get(key);
						data.put(key, val);
					}
					// 将表单的值放入httpPost中
					httpPost.setEntity(new StringEntity(data.toString()));
				}
			}
			// 执行httpPost
			HttpResponse response;
			response = httpClient.execute(httpPost);
			int code = response.getStatusLine().getStatusCode();
			if(code!=200){
				throw new FCException();
			}
			if (httpClient!= null) {
				httpClient.getConnectionManager().shutdown();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			throw new FCNetworkUnconnectedException();
		} catch (Exception e) {
			e.printStackTrace();
			throw new FCException();
		}
	}

	static FCHttpClient getInstance() {
		if (fCHttpClient == null) {
			fCHttpClient = new FCHttpClient();
		}
		return fCHttpClient;
	}
}
