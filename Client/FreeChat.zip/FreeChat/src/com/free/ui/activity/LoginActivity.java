package com.free.ui.activity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.free.ui.R;
import com.free.ui.R.layout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

//import com.easemob.EMCallBack;
//import com.easemob.chat.EMChatManager;
//import com.easemob.chat.EMGroupManager;
//import com.easemob.chatuidemo.Constant;
//import com.easemob.chatuidemo.DemoApplication;
//import com.easemob.chatuidemo.R;
//import com.easemob.chatuidemo.db.UserDao;
//import com.easemob.chatuidemo.domain.User;
//import com.easemob.chatuidemo.utils.CommonUtils;
//import com.easemob.util.HanziToPinyin;

/**
 * 登陆页面
 * 
 */
public class LoginActivity extends BaseActivity {
	private EditText usernameEditText;
	private EditText passwordEditText;

	private TextView forgetPasswdTextView;
	private TextView userRegisterTextView;
	private boolean progressShow;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		// 自定义超链接
		forgetPasswdTextView=(TextView)findViewById(R.id.tv_forgetpasswd);
        userRegisterTextView=(TextView)findViewById(R.id.tv_userregister); 
		String forgetPasswdStr="忘记密码";
        String userRegisterStr="用户注册";	
		SpannableString fgtPwdSpanStr=new SpannableString(forgetPasswdStr);
		SpannableString usrrgtSpanStr=new SpannableString(userRegisterStr);
		usrrgtSpanStr.setSpan(new ClickableSpan() {
			@Override
			public void updateDrawState(TextPaint ds) {
			    ds.setColor(ds.linkColor);
			    ds.setUnderlineText(false); //去掉下划线		    
			}
			@Override
			public void onClick(View widget) {
				// 启动RegisterActivity进行注册
				Intent intent=new Intent(LoginActivity.this,RegisterActivity.class);
				startActivity(intent);
				
			}
		}, 0, userRegisterStr.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		
		userRegisterTextView.setText(usrrgtSpanStr);
		userRegisterTextView.setMovementMethod(LinkMovementMethod.getInstance());
//		usernameEditText = (EditText) findViewById(R.id.username);
//		passwordEditText = (EditText) findViewById(R.id.password);
//		// 如果用户名密码都有，直接进入主页面
//		if (DemoApplication.getInstance().getUserName() != null && DemoApplication.getInstance().getPassword() != null) {
//			startActivity(new Intent(this, MainActivity.class));
//			finish();
//		}
//		// 如果用户名改变，清空密码
//		usernameEditText.addTextChangedListener(new TextWatcher() {
//			@Override
//			public void onTextChanged(CharSequence s, int start, int before, int count) {
//				passwordEditText.setText(null);
//			}
//
//			@Override
//			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//			}
//
//			@Override
//			public void afterTextChanged(Editable s) {
//
//			}
//		});

	}


}
