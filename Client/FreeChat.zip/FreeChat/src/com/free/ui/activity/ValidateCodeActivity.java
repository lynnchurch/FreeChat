package com.free.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.free.ui.R;
import com.free.util.FCCountDownTimer;
import com.free.util.FCValidateCodeEmail;

public class ValidateCodeActivity extends BaseActivity {
	private TextView emailAddressTextView;
	private Button resendMailButton;
	private EditText validateCodeEditText;
	private String validateCode;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
		setContentView(R.layout.activity_validate_code);
		// 加载自定义标题栏
		getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,
				R.layout.titlebar_validate_code);
		emailAddressTextView = (TextView) findViewById(R.id.email_address_hint);
		emailAddressTextView
				.setText(getIntent().getStringExtra("emailAddress"));
		resendMailButton = (Button) findViewById(R.id.resend_mail);
		validateCodeEditText = (EditText) findViewById(R.id.validate_code);
		sendEmail(getIntent().getStringExtra("emailAddress"));
	}

	public void back(View view) {
		finish();
	}

	public void next(View view) {
		String validateCode = validateCodeEditText.getText().toString().trim();
		if (TextUtils.isEmpty(validateCode)) {
			Toast toast = Toast.makeText(ValidateCodeActivity.this, "请输入验证码！",
					Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
			return;
		}
		if(!validateCode.equals(this.validateCode)){
			Toast toast = Toast.makeText(ValidateCodeActivity.this, "验证码错误！",
					Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.CENTER, 0, 0);
			toast.show();
			return;
		}
		// Intent intent = new Intent(ValidateCodeActivity.this,
		// ValidateCodeActivity.class);
		// intent.putExtra("email_address",getIntent().getStringExtra("email_address"));
		// startActivity(intent);
	}

	public String sendEmail(final String emailAddress) {
		new FCCountDownTimer(60000, 1000, resendMailButton).start();
		new Thread(new Runnable() {
			public void run() {
				try {
					validateCode = FCValidateCodeEmail.getInstance().sendEmail(
							emailAddress);
				} catch (final Exception e) {
					runOnUiThread(new Runnable() {
						public void run() {
							if (e != null && e.getMessage() != null) {
								String errorMsg = e.getMessage();
								if (errorMsg
										.indexOf("EMNetworkUnconnectedException") != -1) {
									Toast toast = Toast.makeText(
											ValidateCodeActivity.this,
											"网络异常，请检查网络！", Toast.LENGTH_SHORT);
									toast.setGravity(Gravity.CENTER, 0, 0);
									toast.show();
								} else {
								}
								Toast toast = Toast.makeText(
										ValidateCodeActivity.this, "未知异常!", Toast.LENGTH_LONG);
								toast.setGravity(Gravity.CENTER, 0, 0);
								toast.show();
							} else {
								Toast toast = Toast.makeText(
										ValidateCodeActivity.this, "未知异常!", Toast.LENGTH_LONG);
								toast.setGravity(Gravity.CENTER, 0, 0);
								toast.show();
							}
						}
					});
				}
			}
		}).start();
		return validateCode;
	}
}
