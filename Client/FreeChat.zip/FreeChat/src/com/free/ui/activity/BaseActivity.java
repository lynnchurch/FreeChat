package com.free.ui.activity;

//import com.free.chat.ChatManager;

import android.app.Activity;

public class BaseActivity extends Activity{
	@Override
	protected void onResume() {
		super.onResume();
		//onresume时，取消notification显示
		//ChatManager.getInstance().activityResumed();
	}
}
