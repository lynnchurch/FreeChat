package com.free.exception;

public class FCNetworkUnconnectedException
extends FCException
{
private static final long serialVersionUID = 1L;

public FCNetworkUnconnectedException() {}

public FCNetworkUnconnectedException(String paramString)
{
  super(paramString);
}

public FCNetworkUnconnectedException(String paramString, Throwable paramThrowable)
{
  super(paramString);
  super.initCause(paramThrowable);
}
}